/fanning                                                   February 2010

The procedures in this directory are taken from the IDL program library (the
"Coyote library" developed by David Fanning ( http://www.dfanning.com/ ).   They
are duplicated here either  because they are used by other procedures in the
Astronomy library, or because they are strongly related to Astronomy.    Users
who have already have the Coyote library installed can delete this
directory.     Please inform  wayne.landsman@nasa.gov if there are any
discrepancies between these procedures and those in the current Coyote library.  


Contents of /pro/fanning

SETDEFAULTVALUE  - Set default values for positional and keyword arguments
SYMCAT() - Provide plotting symbols not in the standard PSYM definitions.
